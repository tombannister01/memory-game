console.log('up and running')
let cardOne = 'queen';
let cardTwo = 'king';
let cardThree = 'queen';
let cardFour = 'king';
console.log("User flipped " + cardOne);
console.log("User flipped " + cardTwo);
